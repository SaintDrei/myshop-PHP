 <?php 
    include "config.php";
    include "function.php";

    addToCart($con, 5, 13);

?>