            </div>
        </div>
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Made by <a href="#">Santos, Andrei Mishael</a></p>
                </div>
            </div>
        </footer>
    </div>
    <script type="text/javascript" src='<?php echo app_path ?>js/bootstrap.min.js'></script>
    <script type="text/javascript" src='<?php echo app_path ?>js/jasny-bootstrap.min.js'></script>
</body>
</html>